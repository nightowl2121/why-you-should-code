# Catalyst Project Page

This repository is a step by step tutorial to build your own project page for a hackathon project

Each GitHub commit will correspond to a step in the tutorial

You can view the Gitorial [here](http://www.kaufer.org/gitorial-viewer/?address=HackGT/catalyst-project-page&fileName=index.html) by clicking "Show Me My Gitorial"